# Sachin Kumar Portfolio

Responsive static portfolio website.

## Files
- index.html
- styles.css
- script.js
- resume.pdf (add your verified final PDF)

## GitHub Pages
Create a repository named `sachin-kumar-portfolio`, upload the files, then open:
Settings → Pages → Deploy from a branch → main → /(root) → Save.

Your public URL will normally be:
https://YOUR-GITHUB-USERNAME.github.io/sachin-kumar-portfolio/

## Notes
The site uses the requested public name “Sachin Kumar”. Verify the final resume name before publishing. The contact form is a front-end demo until connected to a form/backend service.
